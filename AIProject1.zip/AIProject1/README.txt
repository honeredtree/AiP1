Created by James Prial, Miraj Jiyani, Isaac Duan

USAGE: to launch, type “python3 Driver.py” in a terminal within the directory containing the source code.
From there, the program will prompt you with instructions, first if you want to generate grids, then the path to
The grid being searched over, and finally the type of search to perform. The path will be written out in the terminal, and a visual representation will pop up to display the path. When the popup is closed out, the program will loop back to the beginning
